import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jobsearch',
  templateUrl: './jobsearch.component.html',
  styleUrls: ['./jobsearch.component.css']
})
export class JobsearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
