import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FeedbackComponent } from './feedback/feedback.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { ContactComponent } from './Contact/Contact.component';
import { JobsearchComponent } from './jobsearch/jobsearch.component';
import { ResumeuploadComponent } from './resumeupload/resumeupload.component';
const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'Signup',component:SignupComponent},
  {path:'Login',component:LoginComponent},
  {path:'Contact',component:ContactComponent},
  {path:'Feedback',component:FeedbackComponent},
  {path:'Jobsearch',component:JobsearchComponent},
  {path:'Resumeupload',component:ResumeuploadComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
